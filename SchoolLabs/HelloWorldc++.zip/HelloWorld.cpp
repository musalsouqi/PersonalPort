#include <iostream>
// Mustafa Alsouqi Date: 7/5/2024
int main() {
    std::cout << "Hello, World!" << std::endl; // Output "Hello, World!"
    return 0;
}